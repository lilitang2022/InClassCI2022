from setuptools import setup, find_packages

setup(
    name='ubcpkg',
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='MDS quiz package',
	url='https://github.com/lilitang2022/InClassCI2022.git',
    author='Justin',
    author_email='chanpaklam321@gmail.com'
)